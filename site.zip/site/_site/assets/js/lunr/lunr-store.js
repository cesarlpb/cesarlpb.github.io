var store = [{
        "title": "Hello, world",
        "excerpt":"Hello, world Conversation handsome hub cosy, enim emerging sed K-pop velit Gaggenau charming proident et boulevard ryokan. Remarkable airport deserunt international est, nulla minim magna emerging discerning in exclusive dolor. Commodo dolore deserunt cosy, global Nordic culpa uniforms signature charming. Smart ryokan commodo, eiusmod global occaecat incididunt aliqua Beams. Boulevard...","categories": ["BGL"],
        "tags": ["Hello world","test"],
        "url": "/site/bgl/hello-world/",
        "teaser": "https://via.placeholder.com/500x300.png"
      },{
        "title": "Hello, world 2",
        "excerpt":"Hello, world Conversation handsome hub cosy, enim emerging sed K-pop velit Gaggenau charming proident et boulevard ryokan. Remarkable airport deserunt international est, nulla minim magna emerging discerning in exclusive dolor. Commodo dolore deserunt cosy, global Nordic culpa uniforms signature charming. Smart ryokan commodo, eiusmod global occaecat incididunt aliqua Beams. Boulevard...","categories": ["BGL"],
        "tags": ["Hello world","test"],
        "url": "/site/bgl/hello-world2/",
        "teaser": "https://via.placeholder.com/500x300.png"
      },{
        "title": "Hello, world 3",
        "excerpt":"Hello, world Conversation handsome hub cosy, enim emerging sed K-pop velit Gaggenau charming proident et boulevard ryokan. Remarkable airport deserunt international est, nulla minim magna emerging discerning in exclusive dolor. Commodo dolore deserunt cosy, global Nordic culpa uniforms signature charming. Smart ryokan commodo, eiusmod global occaecat incididunt aliqua Beams. Boulevard...","categories": ["BGL"],
        "tags": ["Hello world","test"],
        "url": "/site/bgl/hello-world3/",
        "teaser": "https://via.placeholder.com/500x300.png"
      }]
